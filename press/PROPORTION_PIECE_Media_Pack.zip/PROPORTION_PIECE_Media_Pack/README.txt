PROPORTION PIECE (formerly ALGO/ART)
Press / editorial kit, 27 October 2026

Creator: Adam Clement
Contact: southernadd@googlemail.com
Interactive drawing machine: https://southernadd-cmyk.github.io/algoart/
3D Gallery: https://southernadd-cmyk.github.io/algoart/gallery/visit/
Press page: https://southernadd-cmyk.github.io/algoart/press/

Contains a three-page press PDF, six original 2D artwork images, a virtual tower preview and credit information.
Please credit PROPORTION PIECE / Adam Clement and request permission to reproduce artwork.
