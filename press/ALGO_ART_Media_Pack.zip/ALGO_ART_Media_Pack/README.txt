ALGO/ART - MEDIA PACK
Creator: Adam Clement
Press contact: southernadd@googlemail.com
Press page: https://southernadd-cmyk.github.io/algoart/press/
Interactive editor: https://southernadd-cmyk.github.io/algoart/
Source: https://github.com/southernadd-cmyk/algoart

Contains six original, unmodified ALGO/ART JPG artworks from the gallery, caption metadata and a concise one-page PDF press overview.

Publication credit: ALGO/ART / Adam Clement. Please request permission for editorial reproduction.
