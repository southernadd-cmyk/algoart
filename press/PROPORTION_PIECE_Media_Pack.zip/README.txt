PROPORTION PIECE / Adam Clement — press assets
Updated 28 October 2026

Image files: one current 3D tower image and six curated studies from 28 October 2026.
The daily archive provides newer works.

Editor: https://southernadd-cmyk.github.io/algoart/
Tower: https://southernadd-cmyk.github.io/algoart/gallery/visit/
Daily archive: https://southernadd-cmyk.github.io/algoart/gallery/
Credit: PROPORTION PIECE / Adam Clement
Contact to confirm reproduction permission: southernadd@googlemail.com
